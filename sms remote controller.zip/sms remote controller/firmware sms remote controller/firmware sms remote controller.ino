#include <SoftwareSerial.h>
SoftwareSerial mySerial(10,11);  // (Rx,Tx  > Tx,Rx) 

char incomingByte;
String inputString;
String text;
String number;
String num;
String CellNumtemp;
String CellNum;
int n;
int k=0;
int t=0;
int s=0;
int m=0;
int h=0;
int hour=0;
int relay = 4;
int gled=5;
int bled=8;

void setup() 
{
      pinMode(relay, OUTPUT);
      digitalWrite(relay, LOW);
      pinMode(gled, OUTPUT);
      pinMode(bled, OUTPUT);
      pinMode(6, OUTPUT);
      pinMode(9, OUTPUT);
      digitalWrite(6, LOW);
      digitalWrite(9, LOW);
      Serial.begin(9600);
      mySerial.begin(9600); 
      delay(60000);

     while(!mySerial.available()){
        mySerial.println("AT");
        delay(1000); 
        Serial.println("Connecting...");
        }
      Serial.println("Connected!");  
      mySerial.println("AT+CMGF=1");  //Set SMS to Text Mode 
      delay(1000);  
      mySerial.println("AT+CNMI=1,2,0,0,0");  //Procedure to handle newly arrived messages(command name in text: new message indications to TE) 
      delay(1000);
      mySerial.println("AT+CMGL=\"REC UNREAD\""); // Read Unread Messages
      delay(1000);
     }

void loop()
{  
  digitalWrite(gled, HIGH);
  delay(100);
  digitalWrite(gled, LOW);
  delay(100);
  if(mySerial.available()){
      delay(100);
     
      while(mySerial.available()){
        incomingByte = mySerial.read();
        inputString += incomingByte; 
        }
        CellNumtemp = inputString.substring(inputString.indexOf("+98"));
        CellNum = CellNumtemp.substring(0,13);
        if (n==0){
          number=CellNum;
        }
        num=CellNum;
     
        delay(10);      
        
        Serial.println(inputString);
        inputString.toUpperCase(); 

        if (inputString.indexOf("ON") > -1){
          digitalWrite(relay, HIGH);
          digitalWrite(bled, HIGH);
          k=1;
          text="PUMP ON";
          smss();
          }
         if (inputString.indexOf("OFF") > -1){
          digitalWrite(relay, LOW);
          digitalWrite(bled, LOW);
          k=0;
          t=0;
          s=0;
          m=0;
          h=0;
          n=0;
          hour=0;
          text="PUMP OFF";
          smss();
          }    
         if (inputString.indexOf("CH") > -1){
          if (digitalRead(relay)==1){
            text="PUMP ON";
            smss();      
          }
          else if (digitalRead(relay)==0){
            text="PUMP OFF";
            smss();
          }
         }
         if (inputString.indexOf("T1") > -1){
          digitalWrite(relay, 1);
          digitalWrite(bled, HIGH);
          k=1;
          t=1;
          hour=1;
          n=1;
          text="PUMP ON";
          sms();
         }
         if (inputString.indexOf("T2") > -1){
          digitalWrite(relay, 1);
          digitalWrite(bled, HIGH);
          k=1;
          t=1;
          hour=2;
          n=1;
          text="PUMP ON";
          sms();
         }
         if (inputString.indexOf("T3") > -1){
          digitalWrite(relay, 1);
          digitalWrite(bled, HIGH);
          k=1;
          t=1;
          hour=3;
          n=1;
          text="PUMP ON";
          sms();
         }
         if (inputString.indexOf("T4") > -1){
          digitalWrite(relay, 1);
          digitalWrite(bled, HIGH);
          k=1;
          t=1;
          hour=4;
          n=1;
          text="PUMP ON";
          sms();
         }
         if (inputString.indexOf("T5") > -1){
          digitalWrite(relay, 1);
          digitalWrite(bled, HIGH);
          k=1;
          t=1;
          hour=5;
          n=1;
          text="PUMP ON";
          sms();
         }
         if (inputString.indexOf("T6") > -1){
          digitalWrite(relay, 1);
          digitalWrite(bled, HIGH);
          k=1;
          t=1;
          hour=6;
          n=1;
          text="PUMP ON";
          sms();
         }
         if (inputString.indexOf("T7") > -1){
          digitalWrite(relay, 1);
          digitalWrite(bled, HIGH);
          k=1;
          t=1;
          hour=7;
          n=1;
          text="PUMP ON";
          sms();
         }
         if (inputString.indexOf("T8") > -1){
          digitalWrite(relay, 1);
          digitalWrite(bled, HIGH);
          k=1;
          t=1;
          hour=8;
          n=1;
          text="PUMP ON";
          sms();
         }
         if (inputString.indexOf("T9") > -1){
          digitalWrite(relay, 1);
          digitalWrite(bled, HIGH);
          k=1;
          t=1;
          hour=9;
          n=1;
          text="PUMP ON";
          sms();
         }
         if(inputString.indexOf("RING\r") > -1){
          if (k==0){
            k=1;
            mySerial.println("ATH");
            digitalWrite(relay, HIGH);
            digitalWrite(bled, HIGH);
            text="PUMP ON";
            sms();
          }
          else if(k==1){
            k=0;
            mySerial.println("ATH");
            digitalWrite(relay, LOW);
            digitalWrite(bled, LOW);
            t=0;
            s=0;
            m=0;
            h=0;
            n=0;
            hour=0;
            text="PUMP OFF";
            sms();
          }
        }
         delay(10);

        inputString = ("");
  }
  if(t==1){
    s+=1;
    if (s==60){
      s=0;
      m+=1;
    }
    if (m==60){
      m=0;
      h+=1;
    }
    if (h==24){
      h=0;
    }
    delay(790);
    if (h==hour){
      digitalWrite(relay, 0);
      digitalWrite(bled, LOW);
      k=0;
      s=0;
      m=0;
      h=0;
      t=0;
      n=0;
      hour=0;
      text="PUMP OFF";
      sms();
    }
  }
}
void sms()
{
  mySerial.println("AT+CSMP=17,167,2,25\r");
   delay(250);
   mySerial.println("AT");
   delay(250);
   mySerial.println("AT+CMGF=1");
   delay(250);
   mySerial.println("AT+CMGS=\""+number+"\"\r");
   delay(250);
   mySerial.print(text);
   delay(250);
   mySerial.write(26);
   delay(250);
   CellNumtemp = "";
   inputString = "";
   return;
}

void smss()
{
  mySerial.println("AT+CSMP=17,167,2,25\r");
   delay(250);
   mySerial.println("AT");
   delay(250);
   mySerial.println("AT+CMGF=1");
   delay(250);
   mySerial.println("AT+CMGS=\""+num+"\"\r");
   delay(250);
   mySerial.print(text);
   delay(250);
   mySerial.write(26);
   delay(250);
   CellNumtemp = "";
   inputString = "";
   return;
}
